
import React, { useState, useEffect } from 'react';
import { View, Theme } from './types';
import Dashboard from './views/Dashboard';
import ReviewList from './views/ReviewList';
import Plan from './views/Plan';
import Analytics from './views/Analytics';
import Achievements from './views/Achievements';
import Settings from './views/Settings';
import FocusMode from './views/FocusMode';
import AddTheme from './views/AddTheme';
import ThemeDetails from './views/ThemeDetails';
import Auth from './views/Auth';

const INITIAL_THEMES: Theme[] = [
  {
    id: '1',
    name: 'Pancreatite Aguda',
    specialty: 'Gastroenterologia',
    area: 'Clínica Médica',
    accuracy: 85,
    lastReview: 'há 4 dias',
    nextReview: 'Amanhã 09:00',
    srsLevel: 4,
    difficulty: 'Difícil',
    retentionRate: 85,
    questionsTotal: 45,
    questionsCorrect: 38
  },
  {
    id: '2',
    name: 'Fibrilação Atrial',
    specialty: 'Cardiologia',
    area: 'Clínica Médica',
    accuracy: 60,
    lastReview: 'há 2 dias',
    nextReview: 'Hoje 14:00',
    srsLevel: 2,
    difficulty: 'Médio',
    retentionRate: 72,
    questionsTotal: 30,
    questionsCorrect: 18
  },
  {
    id: '3',
    name: 'Diabetes Tipo 2',
    specialty: 'Endocrinologia',
    area: 'Clínica Médica',
    accuracy: 40,
    lastReview: 'há 1 semana',
    nextReview: 'Amanhã 08:00',
    srsLevel: 1,
    difficulty: 'Falha',
    retentionRate: 45,
    questionsTotal: 50,
    questionsCorrect: 20
  }
];

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>(View.LOGIN);
  const [themes, setThemes] = useState<Theme[]>(INITIAL_THEMES);
  const [selectedThemeId, setSelectedThemeId] = useState<string | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(true);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const navigateTo = (view: View, themeId?: string) => {
    if (themeId) setSelectedThemeId(themeId);
    setCurrentView(view);
  };

  const selectedTheme = themes.find(t => t.id === selectedThemeId) || themes[0];

  const renderView = () => {
    switch (currentView) {
      case View.LOGIN:
      case View.SIGNUP:
        return <Auth mode={currentView} onAuthSuccess={() => navigateTo(View.DASHBOARD)} onToggleMode={() => navigateTo(currentView === View.LOGIN ? View.SIGNUP : View.LOGIN)} />;
      case View.DASHBOARD:
        return <Dashboard onNavigate={navigateTo} themes={themes} />;
      case View.REVIEWS:
        return <ReviewList onNavigate={navigateTo} themes={themes} />;
      case View.PLAN:
        return <Plan onNavigate={navigateTo} />;
      case View.ANALYTICS:
        return <Analytics onNavigate={navigateTo} />;
      case View.ACHIEVEMENTS:
        return <Achievements onNavigate={navigateTo} />;
      case View.SETTINGS:
        return <Settings onNavigate={navigateTo} isDarkMode={isDarkMode} onToggleTheme={() => setIsDarkMode(!isDarkMode)} />;
      case View.FOCUS:
        return <FocusMode onNavigate={navigateTo} onExit={() => navigateTo(View.DASHBOARD)} />;
      case View.ADD_THEME:
        return <AddTheme onNavigate={navigateTo} onSave={(t) => setThemes([t, ...themes])} />;
      case View.THEME_DETAILS:
        return <ThemeDetails theme={selectedTheme} onNavigate={navigateTo} />;
      default:
        return <Dashboard onNavigate={navigateTo} themes={themes} />;
    }
  };

  return (
    <div className="min-h-screen bg-background-light dark:bg-background-dark text-slate-900 dark:text-white overflow-x-hidden">
      {renderView()}
    </div>
  );
};

export default App;
