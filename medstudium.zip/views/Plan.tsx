
import React from 'react';
import { View } from '../types';
import { Navbar, Header } from '../components/Layout';

interface Props {
  onNavigate: (view: View) => void;
}

const Plan: React.FC<Props> = ({ onNavigate }) => {
  const days = [
    { label: 'Hoje', date: 'Seg, 24 Out', tasks: [
      { id: '1', title: 'Pediatria: Marcos', desc: 'Fases do desenvolvimento de 0-5 anos.', type: 'Novo Estudo', time: '45m', qs: '20 Qs', highlight: true },
      { id: '2', title: 'Cirurgia: Apendicite', desc: 'Diagnóstico & Escore de Alvarado.', type: 'Revisão', time: '15m', qs: 'Flashcards' }
    ]},
    { label: 'Amanhã', date: 'Ter, 25 Out', tasks: [
      { id: '3', title: 'GO: Pré-natal', desc: 'Protocolos atualizados.', type: 'Novo Estudo', time: '60m', qs: '25 Qs' }
    ]}
  ];

  return (
    <div className="flex flex-col min-h-screen pb-24">
      <Header title="Plano Semanal" onBack={() => onNavigate(View.DASHBOARD)} />
      
      <main className="flex flex-col gap-6 p-4 max-w-md mx-auto w-full">
        <section className="flex flex-col gap-1">
          <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Semana Atual</p>
          <div className="flex items-end justify-between">
            <h1 className="text-2xl font-extrabold">Out 23 - Out 29</h1>
            <div className="flex items-center gap-x-2 rounded-full bg-green-500/10 px-3 py-1 border border-green-500/20">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
              </span>
              <p className="text-green-700 dark:text-green-400 text-[10px] font-bold">No Prazo</p>
            </div>
          </div>
        </section>

        <section className="p-4 rounded-2xl bg-white dark:bg-card-dark shadow-sm border border-gray-100 dark:border-gray-800">
          <div className="flex justify-between items-center mb-2">
            <p className="text-sm font-bold">Progresso de Hoje</p>
            <p className="text-primary text-xs font-bold">2/5 Tarefas</p>
          </div>
          <div className="h-2.5 w-full rounded-full bg-gray-100 dark:bg-gray-700 overflow-hidden">
            <div className="h-full rounded-full bg-primary transition-all duration-500" style={{ width: '40%' }}></div>
          </div>
        </section>

        {days.map(day => (
          <section key={day.label} className="flex flex-col gap-3">
            <h3 className="text-lg font-bold flex items-center gap-2">
              {day.label} <span className="text-gray-400 text-sm font-medium">{day.date}</span>
            </h3>
            <div className="flex flex-col gap-4">
              {day.tasks.map(task => (
                <div 
                  key={task.id}
                  className={`relative overflow-hidden rounded-2xl p-5 shadow-sm border transition-transform active:scale-95 ${
                    task.highlight 
                      ? 'bg-primary text-white border-transparent' 
                      : 'bg-white dark:bg-card-dark border-gray-100 dark:border-gray-800'
                  }`}
                >
                  <div className="flex justify-between items-start mb-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                      task.highlight ? 'bg-white/20' : 'bg-primary/10 text-primary'
                    }`}>
                      {task.type}
                    </span>
                    <span className="material-symbols-outlined text-[20px] opacity-70">check_circle</span>
                  </div>
                  <h4 className="text-lg font-bold mb-1 leading-snug">{task.title}</h4>
                  <p className={`text-sm mb-4 line-clamp-1 ${task.highlight ? 'text-blue-100' : 'text-slate-500'}`}>{task.desc}</p>
                  <div className="flex items-center gap-3 text-[10px] font-bold">
                    <div className={`flex items-center gap-1 px-2 py-1 rounded ${task.highlight ? 'bg-black/20' : 'bg-slate-100 dark:bg-slate-800'}`}>
                      <span className="material-symbols-outlined text-xs">schedule</span>
                      <span>{task.time}</span>
                    </div>
                    <div className={`flex items-center gap-1 px-2 py-1 rounded ${task.highlight ? 'bg-black/20' : 'bg-slate-100 dark:bg-slate-800'}`}>
                      <span className="material-symbols-outlined text-xs">quiz</span>
                      <span>{task.qs}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        ))}
      </main>

      <Navbar currentView={View.PLAN} onNavigate={onNavigate} />
    </div>
  );
};

export default Plan;
