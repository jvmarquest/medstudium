
import React, { useState } from 'react';
import { Theme, View } from '../types';
import { Header } from '../components/Layout';

interface Props {
  onNavigate: (view: View) => void;
  onSave: (theme: Theme) => void;
}

const AddTheme: React.FC<Props> = ({ onNavigate, onSave }) => {
  const [name, setName] = useState('');
  const [total, setTotal] = useState(0);
  const [correct, setCorrect] = useState(0);

  const handleSubmit = () => {
    if (!name) return;
    const accuracy = total > 0 ? Math.round((correct / total) * 100) : 0;
    const newTheme: Theme = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      specialty: 'Clínica Médica',
      area: 'Nefrologia',
      accuracy,
      lastReview: 'Hoje',
      nextReview: 'Amanhã 09:00',
      srsLevel: 1,
      difficulty: accuracy > 80 ? 'Fácil' : accuracy > 50 ? 'Médio' : 'Difícil',
      retentionRate: accuracy,
      questionsTotal: total,
      questionsCorrect: correct
    };
    onSave(newTheme);
    onNavigate(View.DASHBOARD);
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header title="Cadastrar Novo Tema" onBack={() => onNavigate(View.DASHBOARD)} />
      
      <main className="flex-1 overflow-y-auto p-4 max-w-md mx-auto w-full pb-24 space-y-6">
        <div className="space-y-2">
          <label className="text-sm font-bold">Nome do Tema</label>
          <input 
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full h-14 px-4 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-surface-dark outline-none focus:ring-2 focus:ring-primary/50" 
            placeholder="ex. Injúria Renal Aguda" 
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-bold">Total de Questões</label>
            <input 
              type="number"
              value={total}
              onChange={(e) => setTotal(parseInt(e.target.value) || 0)}
              className="w-full h-14 text-center text-lg font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-surface-dark outline-none focus:ring-2 focus:ring-primary/50" 
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-bold text-green-500">Acertos</label>
            <input 
              type="number"
              value={correct}
              onChange={(e) => setCorrect(parseInt(e.target.value) || 0)}
              className="w-full h-14 text-center text-lg font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-surface-dark outline-none focus:ring-2 focus:ring-green-500/50" 
            />
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-surface-dark border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden">
          <div className="flex items-center gap-2 mb-4">
            <span className="material-symbols-outlined text-primary text-xl">analytics</span>
            <h3 className="font-bold">Análise Estimada</h3>
          </div>
          <div className="grid grid-cols-2 gap-6">
            <div>
              <span className="text-[10px] font-bold uppercase text-slate-500 tracking-wider">Acurácia</span>
              <p className="text-2xl font-bold text-primary">{total > 0 ? Math.round((correct / total) * 100) : 0}%</p>
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase text-slate-500 tracking-wider">Status</span>
              <p className="text-lg font-bold text-slate-900 dark:text-white">Estudo Inicial</p>
            </div>
          </div>
        </div>

        <button 
          onClick={handleSubmit}
          className="w-full h-14 bg-primary hover:bg-primary-dark text-white rounded-xl font-bold text-lg shadow-lg shadow-primary/25 active:scale-95 transition-all"
        >
          Salvar Tema
        </button>
      </main>
    </div>
  );
};

export default AddTheme;
