
import React from 'react';
import { View } from '../types';

interface Props {
  mode: View.LOGIN | View.SIGNUP;
  onAuthSuccess: () => void;
  onToggleMode: () => void;
}

const Auth: React.FC<Props> = ({ mode, onAuthSuccess, onToggleMode }) => {
  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark">
      <div className="flex flex-col w-full max-w-[480px] mx-auto p-4 flex-1">
        <div className="flex flex-col items-center pt-12 pb-6">
          <div className="flex items-center justify-center size-16 rounded-2xl bg-primary/10 mb-4 shadow-sm">
            <span className="material-symbols-outlined text-primary text-[32px] filled">cardiology</span>
          </div>
          <h1 className="text-2xl font-extrabold tracking-tight">MedStudium</h1>
        </div>

        <div className="text-center mb-8">
          <h2 className="text-[28px] font-bold leading-tight pb-2">
            {mode === View.LOGIN ? 'Bem-vindo de volta' : 'Crie sua conta'}
          </h2>
          <p className="text-slate-500 text-sm font-normal">
            {mode === View.LOGIN 
              ? 'Prepare-se para suas provas de residência.' 
              : 'Junte-se à comunidade de futuros especialistas.'}
          </p>
        </div>

        <form className="flex flex-col gap-4" onSubmit={(e) => { e.preventDefault(); onAuthSuccess(); }}>
          {mode === View.SIGNUP && (
            <div className="flex flex-col gap-2">
              <label className="text-sm font-medium">Nome Completo</label>
              <input 
                className="h-14 px-4 rounded-xl border border-slate-300 dark:border-border-dark bg-white dark:bg-surface-dark focus:ring-2 focus:ring-primary/50 outline-none" 
                placeholder="Dr. João Silva" 
              />
            </div>
          )}
          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium">E-mail</label>
            <input 
              className="h-14 px-4 rounded-xl border border-slate-300 dark:border-border-dark bg-white dark:bg-surface-dark focus:ring-2 focus:ring-primary/50 outline-none" 
              placeholder="medico@hospital.com" 
              type="email" 
            />
          </div>
          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium">Senha</label>
            <div className="relative">
              <input 
                className="w-full h-14 px-4 pr-12 rounded-xl border border-slate-300 dark:border-border-dark bg-white dark:bg-surface-dark focus:ring-2 focus:ring-primary/50 outline-none" 
                placeholder="Digite sua senha" 
                type="password" 
              />
              <button type="button" className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400">
                <span className="material-symbols-outlined">visibility</span>
              </button>
            </div>
          </div>
          
          <button 
            type="submit" 
            className="w-full h-14 mt-4 bg-primary hover:bg-primary-dark text-white text-base font-bold rounded-xl shadow-lg shadow-primary/25 transition-all active:scale-95"
          >
            {mode === View.LOGIN ? 'Entrar' : 'Cadastrar'}
          </button>
        </form>

        <div className="flex items-center gap-4 py-8">
          <div className="h-px flex-1 bg-slate-200 dark:bg-border-dark"></div>
          <p className="text-slate-400 text-sm font-medium">Ou continue com</p>
          <div className="h-px flex-1 bg-slate-200 dark:bg-border-dark"></div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <button className="flex h-12 items-center justify-center gap-2 rounded-lg border border-slate-200 dark:border-border-dark bg-white dark:bg-surface-dark hover:bg-slate-50 transition-colors">
            <span className="text-sm font-medium">Google</span>
          </button>
          <button className="flex h-12 items-center justify-center gap-2 rounded-lg border border-slate-200 dark:border-border-dark bg-white dark:bg-surface-dark hover:bg-slate-50 transition-colors">
            <span className="text-sm font-medium">Apple</span>
          </button>
        </div>

        <div className="mt-auto py-8 text-center">
          <p className="text-slate-500 text-sm">
            {mode === View.LOGIN ? 'Não tem uma conta?' : 'Já tem uma conta?'}
            <button onClick={onToggleMode} className="text-primary font-bold ml-2 hover:underline">
              {mode === View.LOGIN ? 'Cadastre-se' : 'Entrar'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Auth;
