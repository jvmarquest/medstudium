
import React, { useEffect, useState } from 'react';
import { View } from '../types';
import { Navbar, Header } from '../components/Layout';
import { getStudyTips } from '../services/geminiService';

interface Props {
  onNavigate: (view: View) => void;
}

const Analytics: React.FC<Props> = ({ onNavigate }) => {
  const [tips, setTips] = useState<string>('Carregando dicas de estudo...');

  useEffect(() => {
    const fetchTips = async () => {
      const result = await getStudyTips(78);
      setTips(result);
    };
    fetchTips();
  }, []);

  return (
    <div className="flex flex-col min-h-screen pb-24">
      <Header title="Análise" subtitle="Seu progresso num relance" />

      <main className="flex flex-col gap-6 p-4 max-w-md mx-auto w-full">
        <section className="rounded-2xl bg-white dark:bg-card-dark p-6 shadow-sm border border-slate-100 dark:border-slate-800 relative overflow-hidden">
          <div className="relative z-10">
            <p className="text-slate-500 text-xs font-semibold uppercase tracking-wider mb-2">Precisão Geral</p>
            <div className="flex items-baseline gap-3">
              <h2 className="text-4xl font-extrabold tracking-tight">78%</h2>
              <div className="flex items-center gap-1 rounded-full bg-emerald-100 dark:bg-emerald-500/10 px-2 py-0.5 text-emerald-600 dark:text-emerald-400">
                <span className="material-symbols-outlined text-sm font-bold">trending_up</span>
                <span className="text-xs font-bold">+5.2%</span>
              </div>
            </div>
            <p className="mt-2 text-sm text-slate-500">Seu desempenho está <span className="text-emerald-600 font-bold">Melhorando</span>.</p>
          </div>
          <div className="mt-6 h-1.5 w-full rounded-full bg-slate-100 dark:bg-slate-700 overflow-hidden">
            <div className="h-full w-[78%] rounded-full bg-primary"></div>
          </div>
        </section>

        <section className="bg-indigo-50 dark:bg-indigo-900/10 p-4 rounded-xl border border-indigo-100 dark:border-indigo-800">
          <div className="flex items-center gap-2 mb-2">
            <span className="material-symbols-outlined text-indigo-500 text-sm">auto_awesome</span>
            <p className="text-[10px] font-bold uppercase text-indigo-600 dark:text-indigo-400">Dicas da IA</p>
          </div>
          <p className="text-xs text-slate-700 dark:text-slate-300 italic whitespace-pre-wrap">{tips}</p>
        </section>

        <section>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold">Esforço por Especialidade</h3>
          </div>
          <div className="rounded-2xl bg-white dark:bg-card-dark p-6 shadow-sm border border-slate-100 dark:border-slate-800 space-y-5">
            {[
              { label: 'Pediatria', val: 45 },
              { label: 'Cirurgia', val: 30 },
              { label: 'Cardiologia', val: 15 },
              { label: 'Ginecologia', val: 10 }
            ].map(item => (
              <div key={item.label} className="group">
                <div className="flex justify-between text-xs mb-1.5 font-bold">
                  <span>{item.label}</span>
                  <span className="text-slate-500">{item.val}%</span>
                </div>
                <div className="relative h-2 w-full rounded-full bg-slate-100 dark:bg-slate-700/50 overflow-hidden">
                  <div className="absolute h-full rounded-full bg-primary" style={{ width: `${item.val}%` }}></div>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section>
          <div className="flex items-center gap-2 mb-4">
            <span className="flex h-2 w-2 rounded-full bg-red-500"></span>
            <h3 className="text-base font-bold">Áreas de Foco</h3>
          </div>
          <div className="-mx-4 flex gap-4 overflow-x-auto px-4 pb-4 no-scrollbar">
            {[
              { title: 'Lesão Renal Aguda', sub: 'Nefrologia', prec: '42%' },
              { title: 'Marcos do Desenvolvimento', sub: 'Pediatria', prec: '48%' }
            ].map((area, i) => (
              <div key={i} className="flex min-w-[240px] flex-col justify-between rounded-xl bg-white dark:bg-card-dark p-5 shadow-sm border border-slate-100 dark:border-slate-800">
                <div>
                  <h4 className="text-sm font-bold leading-tight mb-1">{area.title}</h4>
                  <p className="text-xs text-slate-500">{area.sub}</p>
                </div>
                <div className="mt-6 flex items-center justify-between">
                  <div>
                    <p className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider">Precisão</p>
                    <p className="text-lg font-bold text-orange-500">{area.prec}</p>
                  </div>
                  <button onClick={() => onNavigate(View.REVIEWS)} className="rounded-lg bg-primary text-white px-3 py-1 text-xs font-bold shadow-md active:scale-95">
                    Revisar
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>

      <Navbar currentView={View.ANALYTICS} onNavigate={onNavigate} />
    </div>
  );
};

export default Analytics;
