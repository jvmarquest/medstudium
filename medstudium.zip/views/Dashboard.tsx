
import React from 'react';
import { View, Theme } from '../types';
import { Navbar } from '../components/Layout';

interface Props {
  onNavigate: (view: View, themeId?: string) => void;
  themes: Theme[];
}

const Dashboard: React.FC<Props> = ({ onNavigate, themes }) => {
  return (
    <div className="flex flex-col min-h-screen pb-24">
      <header className="sticky top-0 z-50 bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-center bg-no-repeat bg-cover rounded-full size-10 ring-2 ring-slate-200 dark:ring-slate-700" style={{ backgroundImage: 'url("https://picsum.photos/seed/doctor/200")' }}></div>
          <div className="flex flex-col">
            <h2 className="text-sm font-medium text-slate-500 dark:text-slate-400 leading-none">Boa noite,</h2>
            <h1 className="text-base font-bold text-slate-900 dark:text-white leading-tight">Dr. Silva</h1>
          </div>
        </div>
        <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-surface-dark px-3 py-1.5 rounded-full border border-slate-200 dark:border-slate-700 shadow-sm">
          <span className="material-symbols-outlined text-orange-500 text-[20px] filled">local_fire_department</span>
          <span className="text-sm font-bold text-slate-800 dark:text-slate-200">45</span>
        </div>
      </header>

      <main className="flex flex-col gap-6 p-4 max-w-md mx-auto w-full">
        <section aria-label="Countdown Timer">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Prova de Residência</h3>
            <span className="text-xs font-medium text-primary bg-primary/10 px-2 py-0.5 rounded-full">15 Nov, 2024</span>
          </div>
          <div className="grid grid-cols-4 gap-3 text-center">
            {[{v: '124', l: 'Dias'}, {v: '08', l: 'Horas'}, {v: '42', l: 'Mins'}, {v: '19', l: 'Segs'}].map((t, i) => (
              <div key={i} className="flex flex-col gap-1">
                <div className="flex aspect-square items-center justify-center rounded-xl bg-white dark:bg-surface-dark shadow-sm border border-slate-200 dark:border-slate-700">
                  <span className="text-xl font-bold">{t.v}</span>
                </div>
                <span className="text-[10px] font-medium text-slate-500 uppercase">{t.l}</span>
              </div>
            ))}
          </div>
        </section>

        <section className="bg-white dark:bg-surface-dark rounded-xl p-4 shadow-sm border border-slate-200 dark:border-slate-700">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-primary text-[20px]">bolt</span>
              <h3 className="text-sm font-bold">Carga Diária</h3>
            </div>
            <span className="text-xs font-bold text-orange-500 bg-orange-500/10 px-2 py-0.5 rounded">Alta</span>
          </div>
          <div className="h-3 w-full bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-primary to-blue-400 w-[80%] rounded-full"></div>
          </div>
          <p className="text-xs text-slate-500 mt-2 text-right">80% da capacidade diária</p>
        </section>

        <section className="bg-gradient-to-br from-surface-dark to-[#0f172a] rounded-xl p-5 shadow-lg border border-slate-800 relative overflow-hidden">
          <div className="flex flex-col gap-4 relative z-10">
            <div>
              <h3 className="text-lg font-bold text-white mb-1">Revisões de Hoje</h3>
              <p className="text-slate-400 text-sm">Você tem <span className="text-white font-bold">145 cartões</span> para revisar.</p>
            </div>
            <button 
              onClick={() => onNavigate(View.REVIEWS)}
              className="bg-primary hover:bg-blue-600 text-white px-5 py-3 rounded-lg font-bold text-sm shadow-lg flex items-center justify-center gap-2"
            >
              <span className="material-symbols-outlined text-[20px]">play_circle</span>
              Iniciar Sessão
            </button>
          </div>
        </section>

        <section>
          <h3 className="text-base font-bold mb-3">Mínimo Recomendado</h3>
          <div className="flex flex-col gap-3">
            {themes.map(theme => (
              <div 
                key={theme.id} 
                onClick={() => onNavigate(View.THEME_DETAILS, theme.id)}
                className="bg-white dark:bg-surface-dark rounded-xl p-3 shadow-sm border border-slate-200 dark:border-slate-700 flex items-center gap-4 cursor-pointer hover:border-primary/50 transition-colors"
              >
                <div className={`size-10 rounded-lg flex items-center justify-center shrink-0 ${
                  theme.difficulty === 'Falha' ? 'bg-red-500/10 text-red-500' : 'bg-primary/10 text-primary'
                }`}>
                  <span className="material-symbols-outlined text-[20px]">
                    {theme.specialty === 'Cardiologia' ? 'cardiology' : 'medical_services'}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-bold truncate">{theme.name}</h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{theme.questionsTotal} Questões no Banco</p>
                </div>
                <span className="material-symbols-outlined text-slate-400">chevron_right</span>
              </div>
            ))}
          </div>
        </section>

        <button 
          onClick={() => onNavigate(View.FOCUS)}
          className="fixed bottom-20 right-4 z-40 flex items-center justify-center w-14 h-14 rounded-full bg-slate-900 dark:bg-white text-white dark:text-primary shadow-xl hover:scale-105 transition-transform"
        >
          <span className="material-symbols-outlined text-[28px]">timer</span>
        </button>
      </main>

      <Navbar currentView={View.DASHBOARD} onNavigate={onNavigate} />
    </div>
  );
};

export default Dashboard;
