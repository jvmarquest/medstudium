
import React from 'react';
import { View } from '../types';
import { Navbar, Header } from '../components/Layout';

interface Props {
  onNavigate: (view: View) => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
}

const Settings: React.FC<Props> = ({ onNavigate, isDarkMode, onToggleTheme }) => {
  return (
    <div className="flex flex-col min-h-screen pb-24">
      <Header title="Configurações" onBack={() => onNavigate(View.DASHBOARD)} />

      <main className="flex flex-col gap-6 p-4 max-w-md mx-auto w-full">
        <div className="flex items-stretch justify-between gap-4 rounded-xl bg-white dark:bg-surface-dark p-4 shadow-sm border border-slate-200 dark:border-slate-800">
          <div className="flex flex-col gap-4 justify-between flex-1">
            <div className="flex flex-col gap-1">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-green-500 text-[18px]">wifi</span>
                <p className="text-base font-bold leading-tight">Sincronização Ativa</p>
              </div>
              <p className="text-slate-500 text-xs font-normal">Seu progresso é salvo na nuvem.</p>
            </div>
            <button className="flex items-center justify-center rounded-lg bg-slate-100 dark:bg-slate-800 px-4 py-1 text-xs font-bold w-fit">
              Configurar
            </button>
          </div>
          <div className="w-24 bg-primary/10 rounded-lg flex items-center justify-center">
            <span className="material-symbols-outlined text-primary text-4xl">cloud_sync</span>
          </div>
        </div>

        <div>
          <h3 className="text-slate-500 text-[10px] font-bold uppercase tracking-wider px-2 pb-2 pt-4">Aparência</h3>
          <div className="flex flex-col overflow-hidden rounded-xl bg-white dark:bg-surface-dark shadow-sm border border-slate-200 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800">
            <div className="flex items-center justify-between p-4">
              <div className="flex items-center gap-4">
                <div className="size-10 flex items-center justify-center rounded-lg bg-slate-100 dark:bg-slate-800">
                  <span className="material-symbols-outlined">{isDarkMode ? 'dark_mode' : 'light_mode'}</span>
                </div>
                <p className="font-medium">Modo Escuro</p>
              </div>
              <button 
                onClick={onToggleTheme}
                className={`relative w-12 h-6 rounded-full transition-colors ${isDarkMode ? 'bg-primary' : 'bg-slate-300'}`}
              >
                <div className={`absolute top-1 size-4 bg-white rounded-full transition-all ${isDarkMode ? 'right-1' : 'left-1'}`}></div>
              </button>
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-slate-500 text-[10px] font-bold uppercase tracking-wider px-2 pb-2 pt-4">Conta</h3>
          <div className="flex flex-col overflow-hidden rounded-xl bg-white dark:bg-surface-dark shadow-sm border border-slate-200 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800">
            <button className="flex items-center justify-between p-4 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
              <div className="flex items-center gap-4">
                <div className="size-10 flex items-center justify-center rounded-lg bg-slate-100 dark:bg-slate-800">
                  <span className="material-symbols-outlined">person</span>
                </div>
                <p className="font-medium">Editar Perfil</p>
              </div>
              <span className="material-symbols-outlined text-slate-400">chevron_right</span>
            </button>
            <button className="flex items-center justify-between p-4 hover:bg-red-50 dark:hover:bg-red-900/10 transition-colors text-red-500">
              <div className="flex items-center gap-4">
                <div className="size-10 flex items-center justify-center rounded-lg bg-red-50 dark:bg-red-900/20">
                  <span className="material-symbols-outlined">logout</span>
                </div>
                <p className="font-medium">Sair da Conta</p>
              </div>
            </button>
          </div>
        </div>
      </main>

      <Navbar currentView={View.SETTINGS} onNavigate={onNavigate} />
    </div>
  );
};

export default Settings;
