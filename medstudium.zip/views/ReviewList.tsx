
import React from 'react';
import { View, Theme } from '../types';
import { Navbar, Header } from '../components/Layout';

interface Props {
  onNavigate: (view: View, themeId?: string) => void;
  themes: Theme[];
}

const ReviewList: React.FC<Props> = ({ onNavigate, themes }) => {
  return (
    <div className="flex flex-col min-h-screen pb-24">
      <Header title="Revisões Diárias" subtitle="Bom dia, Dr. Silva" />

      <main className="flex flex-col gap-6 p-4 max-w-md mx-auto w-full">
        <div className="flex flex-col gap-3">
          <div className="flex justify-between items-end">
            <p className="text-base font-bold">Seu Progresso</p>
            <p className="text-slate-500 text-sm font-medium">12/45 Revisados</p>
          </div>
          <div className="rounded-full bg-slate-200 dark:bg-[#324467] overflow-hidden h-3">
            <div className="h-full rounded-full bg-primary transition-all duration-500" style={{ width: '26%' }}></div>
          </div>
          <p className="text-slate-500 text-xs flex items-center gap-1">
            <span className="material-symbols-outlined text-sm">trending_up</span>
            No ritmo para terminar às 18h
          </p>
        </div>

        {themes.map(theme => (
          <div 
            key={theme.id}
            className="flex flex-col bg-white dark:bg-card-dark rounded-xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden"
          >
            <div 
              className="relative h-40 w-full bg-cover bg-center cursor-pointer"
              style={{ 
                backgroundImage: `linear-gradient(0deg, rgba(16, 22, 34, 0.9) 0%, rgba(16, 22, 34, 0.4) 50%, rgba(16, 22, 34, 0) 100%), url("https://picsum.photos/seed/${theme.id}/600/400")` 
              }}
              onClick={() => onNavigate(View.THEME_DETAILS, theme.id)}
            >
              <div className="absolute top-3 left-3 bg-primary/90 text-white text-[10px] font-bold px-2 py-1 rounded uppercase tracking-wider">
                {theme.id === '1' ? 'Para Hoje' : 'Agendado'}
              </div>
              <div className="absolute bottom-3 left-3">
                <p className="text-primary-300 text-[10px] font-bold uppercase tracking-wider">{theme.specialty}</p>
                <p className="text-white text-xl font-bold leading-tight">{theme.name}</p>
              </div>
            </div>
            <div className="p-4 flex flex-col gap-4">
              <div className="flex justify-between items-center pb-2 border-b border-slate-100 dark:border-slate-700/50">
                <div className="flex items-center gap-2 text-slate-500 text-sm">
                  <span className="material-symbols-outlined text-[18px]">history</span>
                  <span>Última: {theme.lastReview}</span>
                </div>
                <button 
                  onClick={() => onNavigate(View.THEME_DETAILS, theme.id)}
                  className="text-primary text-sm font-bold hover:bg-primary/10 px-2 py-1 rounded transition-colors"
                >
                  Ver Detalhes
                </button>
              </div>
              <div className="grid grid-cols-3 gap-3">
                {['Fácil', 'Médio', 'Difícil'].map(lvl => (
                  <button key={lvl} className="h-10 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-bold hover:bg-primary/20 transition-all active:scale-95">
                    {lvl}
                  </button>
                ))}
              </div>
            </div>
          </div>
        ))}
      </main>

      <Navbar currentView={View.REVIEWS} onNavigate={onNavigate} />
    </div>
  );
};

export default ReviewList;
