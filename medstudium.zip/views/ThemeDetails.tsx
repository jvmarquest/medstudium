
import React, { useState } from 'react';
import { Theme, View } from '../types';
import { Header, Navbar } from '../components/Layout';
import { getMedicalExplanation } from '../services/geminiService';

interface Props {
  theme: Theme;
  onNavigate: (view: View) => void;
}

const ThemeDetails: React.FC<Props> = ({ theme, onNavigate }) => {
  const [explanation, setExplanation] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleAskGemini = async () => {
    setLoading(true);
    const result = await getMedicalExplanation(theme.name);
    setExplanation(result);
    setLoading(false);
  };

  return (
    <div className="flex flex-col min-h-screen pb-24">
      <Header title="Detalhes do Tema" onBack={() => onNavigate(View.DASHBOARD)} />
      
      <main className="flex flex-col gap-6 p-4 max-w-lg mx-auto w-full">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="inline-flex items-center rounded-full bg-blue-100 dark:bg-blue-900/30 px-2.5 py-0.5 text-xs font-medium text-blue-800 dark:text-blue-300">
              {theme.specialty}
            </span>
            <span className="inline-flex items-center rounded-full bg-gray-100 dark:bg-gray-800 px-2.5 py-0.5 text-xs font-medium text-gray-800 dark:text-gray-400">
              {theme.area}
            </span>
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight leading-tight">{theme.name}</h1>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="flex flex-col gap-3 rounded-xl p-5 bg-white dark:bg-surface-highlight shadow-sm border border-gray-100 dark:border-gray-800">
            <div className="flex items-center gap-2 text-text-secondary">
              <span className="material-symbols-outlined text-xl">calendar_clock</span>
              <p className="text-[10px] font-bold uppercase tracking-wider">Próxima Revisão</p>
            </div>
            <div>
              <p className="text-primary text-lg font-bold leading-tight">{theme.nextReview.split(' ')[0]}</p>
              <p className="text-slate-500 text-xs font-medium">{theme.nextReview.split(' ')[1]}</p>
            </div>
          </div>
          <div className="flex flex-col gap-3 rounded-xl p-5 bg-white dark:bg-surface-highlight shadow-sm border border-gray-100 dark:border-gray-800">
            <div className="flex items-center gap-2 text-text-secondary">
              <span className="material-symbols-outlined text-xl">psychology</span>
              <p className="text-[10px] font-bold uppercase tracking-wider">Nível SRS</p>
            </div>
            <div>
              <p className="text-lg font-bold leading-tight">Nível {theme.srsLevel}</p>
              <div className="flex items-center gap-1 mt-1">
                <span className={`size-2 rounded-full ${theme.accuracy > 70 ? 'bg-green-500' : 'bg-orange-500'}`}></span>
                <p className="text-xs font-medium">{theme.difficulty}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="rounded-xl bg-white dark:bg-surface-highlight p-5 shadow-sm border border-gray-100 dark:border-gray-800">
          <div className="flex items-center justify-between mb-2">
            <p className="text-text-secondary text-sm font-medium">Taxa de Retenção (30 Dias)</p>
            <div className="flex items-center gap-1 text-green-500 bg-green-500/10 px-2 py-0.5 rounded text-[10px] font-bold">
              <span className="material-symbols-outlined text-xs">trending_up</span>
              <span>+5%</span>
            </div>
          </div>
          <p className="text-3xl font-bold leading-tight mb-4">{theme.retentionRate}%</p>
          <div className="h-2 w-full bg-slate-100 dark:bg-slate-700 rounded-full">
            <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${theme.retentionRate}%` }}></div>
          </div>
        </div>

        <div className="bg-indigo-50 dark:bg-indigo-900/20 rounded-xl p-5 border border-indigo-100 dark:border-indigo-800">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-indigo-500">auto_awesome</span>
              <h3 className="font-bold">Tutor IA</h3>
            </div>
            <button 
              onClick={handleAskGemini}
              disabled={loading}
              className="text-xs font-bold bg-indigo-500 text-white px-3 py-1 rounded-full hover:bg-indigo-600 disabled:opacity-50"
            >
              {loading ? 'Pensando...' : explanation ? 'Atualizar' : 'Explicar Tema'}
            </button>
          </div>
          {explanation ? (
            <div className="text-sm text-slate-700 dark:text-slate-300 prose prose-invert max-w-none whitespace-pre-wrap">
              {explanation}
            </div>
          ) : (
            <p className="text-xs text-slate-500 italic">Dúvidas sobre este tema? Peça ao nosso tutor IA para explicar os pontos chave.</p>
          )}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <button className="flex items-center justify-center rounded-xl h-12 bg-primary hover:bg-primary-dark transition-colors text-white font-bold text-sm shadow-lg shadow-blue-900/20 active:scale-95">
            <span className="mr-2 material-symbols-outlined text-[20px]">play_circle</span>
            Revisar Agora
          </button>
          <button className="flex items-center justify-center rounded-xl h-12 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-sm active:scale-95">
            <span className="mr-2 material-symbols-outlined text-[20px]">check_circle</span>
            Dominado
          </button>
        </div>
      </main>

      <Navbar currentView={View.REVIEWS} onNavigate={onNavigate} />
    </div>
  );
};

export default ThemeDetails;
