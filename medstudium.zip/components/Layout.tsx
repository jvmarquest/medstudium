
import React from 'react';
import { View } from '../types';

interface NavProps {
  currentView: View;
  onNavigate: (view: View) => void;
}

export const Navbar: React.FC<NavProps> = ({ currentView, onNavigate }) => {
  const items = [
    { view: View.DASHBOARD, icon: 'home', label: 'Início' },
    { view: View.REVIEWS, icon: 'style', label: 'Revisões' },
    { view: View.PLAN, icon: 'calendar_month', label: 'Agenda' },
    { view: View.ANALYTICS, icon: 'bar_chart', label: 'Análise' },
    { view: View.SETTINGS, icon: 'settings', label: 'Perfil' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 w-full bg-white dark:bg-card-dark border-t border-slate-200 dark:border-slate-800 z-50 safe-area-pb">
      <div className="max-w-md mx-auto flex items-center justify-around h-16 px-2">
        {items.map((item) => (
          <button
            key={item.view}
            onClick={() => onNavigate(item.view)}
            className={`flex flex-col items-center justify-center gap-1 w-full h-full transition-colors ${
              currentView === item.view ? 'text-primary' : 'text-slate-400 dark:text-[#92a4c9]'
            }`}
          >
            <span className={`material-symbols-outlined text-[24px] ${currentView === item.view ? 'filled' : ''}`}>
              {item.icon}
            </span>
            <span className="text-[10px] font-bold">{item.label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
};

export const Header: React.FC<{ title: string; subtitle?: string; onBack?: () => void }> = ({ title, subtitle, onBack }) => (
  <header className="sticky top-0 z-50 bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 py-3 flex items-center justify-between">
    <div className="flex items-center gap-3">
      {onBack && (
        <button onClick={onBack} className="p-2 -ml-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors">
          <span className="material-symbols-outlined text-2xl">arrow_back</span>
        </button>
      )}
      <div className="flex flex-col">
        {subtitle && <h2 className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">{subtitle}</h2>}
        <h1 className="text-lg font-bold text-slate-900 dark:text-white leading-tight">{title}</h1>
      </div>
    </div>
  </header>
);
